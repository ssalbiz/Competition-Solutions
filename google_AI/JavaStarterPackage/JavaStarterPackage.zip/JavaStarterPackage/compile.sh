javac Strategy.java Helper.java
