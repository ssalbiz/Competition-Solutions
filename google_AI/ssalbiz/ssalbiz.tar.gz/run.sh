java Strategy
