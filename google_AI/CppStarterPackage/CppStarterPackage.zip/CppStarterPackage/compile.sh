g++ -c Helper.cc -o Helper.o
g++ -c Strategy.cc -o Strategy.o
g++ -o strategy Strategy.o Helper.o
